<?php
require_once 'config.php';

// Jeśli już zalogowany, przekieruj na stronę główną
if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Wypełnij wszystkie pola!';
    } else {
        // Przygotuj zapytanie
        $stmt = $conn->prepare("SELECT id, username, haslo, rola FROM uzytkownicy WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            
            if (password_verify($password, $user['haslo'])) {
                // Zalogowano pomyślnie
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['rola'];
                
                showMessage('Zalogowano pomyślnie! Witaj ' . $user['username'], 'success');
                redirect('index.php');
            } else {
                $error = 'Nieprawidłowe hasło!';
            }
        } else {
            $error = 'Nie znaleziono użytkownika!';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie - KonZValony</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <div class="header-content">
        <div class="logo-container">
            <img src="images/image.png" alt="KonZValony - wypożyczalnia koni" class="logo">
        </div>
        <h1>KonZValony</h1>
        <p class="tagline">Wypożyczalnia koni, które mają więcej charakteru niż Twój były!</p>
    </div>
        <nav>
            <ul>
                <li><a href="index.php" class="active">Stajnia</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="mapa.php">Mapa</a></li>
                <?php if (isLoggedIn()): ?>
                    <li><a href="panel.php">Panel</a></li>
                    <li><a href="ulubione.php">Ulubione</a></li>
                    <li><a href="polec.php">Poleć znajomym</a></li>
                    <li><a href="logout.php">Wyloguj (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php">Logowanie</a></li>
                    <li><a href="register.php">Rejestracja</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main>
        <section class="auth-section">
            <div class="auth-container">
                <h2>Logowanie do stajni</h2>
                
                <?php if ($error): ?>
                    <div class="message message-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="" class="auth-form">
                    <div class="form-group">
                        <label for="username">Nazwa użytkownika lub email:</label>
                        <input type="text" id="username" name="username" required 
                               placeholder="Wprowadź nazwę lub email"
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">Hasło:</label>
                        <input type="password" id="password" name="password" required 
                               placeholder="Twoje hasło">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn-submit">Zaloguj się</button>
                    </div>

                    <p class="auth-links">
                        Nie masz konta? <a href="register.php">Zarejestruj się</a>
                    </p>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2026 KonZValony - Wypożyczalnia koni z humorem</p>
    </footer>
<!-- Panel dostępności - umieszczony PRZED skryptem i wewnątrz body -->
    <div class="accessibility-panel">
        <button class="accessibility-toggle" aria-label="Otwórz panel dostępności">
            <span class="accessibility-icon">♿</span>
        </button>
        
        <div class="accessibility-menu">
            <h4>Ułatwienia dostępu</h4>
            
            <div class="accessibility-section">
                <p>Rozmiar czcionki:</p>
                <div class="font-size-controls">
                    <button class="font-size-btn small" data-size="small">A-</button>
                    <button class="font-size-btn normal active" data-size="normal">A</button>
                    <button class="font-size-btn large" data-size="large">A+</button>
                    <button class="font-size-btn xlarge" data-size="xlarge">A++</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <p>Kontrast:</p>
                <div class="contrast-controls">
                    <button class="contrast-btn normal active" data-contrast="normal">Normalny</button>
                    <button class="contrast-btn high" data-contrast="high">Wysoki</button>
                    <button class="contrast-btn dark" data-contrast="dark">Ciemny</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <p>Odstępy:</p>
                <div class="spacing-controls">
                    <button class="spacing-btn normal active" data-spacing="normal">Standard</button>
                    <button class="spacing-btn large" data-spacing="large">Szerokie</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <p>Animacje:</p>
                <div class="motion-controls">
                    <button class="motion-btn normal active" data-motion="normal">Włączone</button>
                    <button class="motion-btn reduced" data-motion="reduced">Wyłączone</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <p>Czytelność:</p>
                <div class="readability-controls">
                    <button class="readability-btn serif" data-readability="serif">Szeryfowa</button>
                    <button class="readability-btn sans active" data-readability="sans">Bezszeryfowa</button>
                    <button class="readability-btn mono" data-readability="mono">Monospace</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <p>Linia pomocnicza:</p>
                <div class="ruler-controls">
                    <button class="ruler-btn off active" data-ruler="off">Wyłącz</button>
                    <button class="ruler-btn line" data-ruler="line">Linia</button>
                    <button class="ruler-btn ruler" data-ruler="ruler">Linijka</button>
                </div>
            </div>
            
            <div class="accessibility-section">
                <button class="reset-all-btn">⟲ Resetuj wszystko</button>
            </div>
            
            <div class="accessibility-footer">
                <small>Ustawienia zapisują się automatycznie</small>
            </div>
        </div>
    </div>
</body>
</html>